# TPI Programación
# Gestión de Datos de Países en Python: filtros, ordenamientos y estadísticas
# Alumnos: Bautista Mariani, Bruno Gatti

import csv

RUTA_CSV = "datos/paises.csv"    # Ruta al archivo CSV


def cargar_paises(ruta):    # Función para cargar los datos de los países en el CSV
    paises = []

    try:
        archivo = open(ruta, "r", encoding="utf-8")     # El CSV en modo lectura UTF-8
        lector = csv.DictReader(archivo)

        for fila in lector:     # En cada fila del CSV y crea un diccionario para cada país
            try:
                pais = {
                    "nombre": fila["nombre"].strip(),
                    "poblacion": int(fila["poblacion"]),
                    "superficie": int(fila["superficie"]),
                    "continente": fila["continente"].strip()
                }
                paises.append(pais)
            except:
                print("Se encontró una fila con datos inválidos.")

        archivo.close()

    except FileNotFoundError:
        print("No se encontró el archivo CSV.")

    return paises


def guardar_paises(ruta, paises):     # Función para guardar los datos de los países en el CSV
    archivo = open(ruta, "w", newline="", encoding="utf-8")

    campos = ["nombre", "poblacion", "superficie", "continente"]

    escritor = csv.DictWriter(archivo, fieldnames=campos)  

    escritor.writeheader()

    for pais in paises:           # Escribe cada país en el archivo CSV
        escritor.writerow(pais)

    archivo.close()


def mostrar_pais(pais):    # Función para mostrar los datos de un país
    print("-" * 50)
    print("Nombre:", pais["nombre"])
    print("Población:", pais["poblacion"])
    print("Superficie:", pais["superficie"], "km²")
    print("Continente:", pais["continente"])


def mostrar_lista_paises(lista):    # Función para mostrar una lista de países
    if len(lista) == 0:
        print("No hay resultados.")

    for pais in lista:
        mostrar_pais(pais)


def agregar_pais(paises):       # Función para agregar un país a la lista de países

    nombre = input("Nombre: ").strip()

    if nombre == "":
        print("El nombre no puede estar vacío.")
        return

    try:
        poblacion = int(input("Población: "))
        superficie = int(input("Superficie: "))
    except ValueError:
        print("Debe ingresar números válidos.")
        return

    continente = input("Continente: ").strip()

    if continente == "":
        print("El continente no puede estar vacío.")
        return

    pais = {
        "nombre": nombre,
        "poblacion": poblacion,
        "superficie": superficie,
        "continente": continente
    }

    paises.append(pais)
    print("País agregado correctamente.")


def actualizar_pais(paises):    # Función para actualizar los datos de un país existente

    nombre = input("Ingrese el país a actualizar: ").lower()

    cantidad = 0

    for pais in paises:

        if pais["nombre"].lower() == nombre:

            try:
                pais["poblacion"] = int(input("Nueva población: "))
                pais["superficie"] = int(input("Nueva superficie: "))
                print("País actualizado.")
            except ValueError:
                print("Datos inválidos.")

            cantidad += 1

    if cantidad == 0:
        print("País no encontrado.")


def buscar_pais(paises):    # Función para buscar un país por nombre

    texto = input("Buscar: ").lower()

    resultados = []

    for pais in paises:

        if texto in pais["nombre"].lower():
            resultados.append(pais)

    mostrar_lista_paises(resultados)


def filtrar_continente(paises):   # Función para filtrar los países por continente

    continente = input("Continente: ").lower()

    resultados = []

    for pais in paises:

        if pais["continente"].lower() == continente:
            resultados.append(pais)

    mostrar_lista_paises(resultados)


def filtrar_poblacion(paises):     # Función para filtrar los países por población

    try:
        minimo = int(input("Población mínima: "))
        maximo = int(input("Población máxima: "))
    except ValueError:
        print("Valores inválidos.")
        return

    resultados = []

    for pais in paises:

        if pais["poblacion"] >= minimo and pais["poblacion"] <= maximo:
            resultados.append(pais)

    mostrar_lista_paises(resultados)


def filtrar_superficie(paises):     # Función para filtrar los países por superficie

    try:
        minimo = int(input("Superficie mínima: "))
        maximo = int(input("Superficie máxima: "))
    except ValueError:
        print("Valores inválidos.")
        return

    resultados = []

    for pais in paises:

        if pais["superficie"] >= minimo and pais["superficie"] <= maximo:
            resultados.append(pais)

    mostrar_lista_paises(resultados)


def ordenar_nombre(paises):     # Función para ordenar los países por nombre de forma ascendente o descendente

    opcion = input("A-Ascendente / D-Descendente: ").upper()

    n = len(paises)

    for i in range(n - 1):
        for j in range(n - i - 1):

            intercambio = False

            if opcion == "A":
                if paises[j]["nombre"].lower() > paises[j + 1]["nombre"].lower():
                    intercambio = True

            elif opcion == "D":
                if paises[j]["nombre"].lower() < paises[j + 1]["nombre"].lower():
                    intercambio = True

            if intercambio:
                aux = paises[j]
                paises[j] = paises[j + 1]
                paises[j + 1] = aux

    mostrar_lista_paises(paises)


def ordenar_poblacion(paises):   # Función para ordenar los países por población de forma ascendente o descendente

    opcion = input("A-Ascendente / D-Descendente: ").upper()

    n = len(paises)

    for i in range(n - 1):
        for j in range(n - i - 1):

            intercambio = False

            if opcion == "A":
                if paises[j]["poblacion"] > paises[j + 1]["poblacion"]:
                    intercambio = True

            elif opcion == "D":
                if paises[j]["poblacion"] < paises[j + 1]["poblacion"]:
                    intercambio = True

            if intercambio:
                aux = paises[j]
                paises[j] = paises[j + 1]
                paises[j + 1] = aux

    mostrar_lista_paises(paises)


def ordenar_superficie(paises):  # Función para ordenar los países por superficie de forma ascendente o descendente

    opcion = input("A-Ascendente / D-Descendente: ").upper()

    n = len(paises)

    for i in range(n - 1):
        for j in range(n - i - 1):

            intercambio = False

            if opcion == "A":
                if paises[j]["superficie"] > paises[j + 1]["superficie"]:
                    intercambio = True

            elif opcion == "D":
                if paises[j]["superficie"] < paises[j + 1]["superficie"]:
                    intercambio = True

            if intercambio:
                aux = paises[j]
                paises[j] = paises[j + 1]
                paises[j + 1] = aux

    mostrar_lista_paises(paises)


def mostrar_estadisticas(paises):     # Función para mostrar estadísticas de los países

    if len(paises) == 0:
        print("No hay datos.")
        return

    mayor = paises[0]
    menor = paises[0]

    suma_poblacion = 0
    suma_superficie = 0

    continentes = {}

    for pais in paises:     # Recorre la lista de países y calcula las estadísticas

        suma_poblacion += pais["poblacion"]
        suma_superficie += pais["superficie"]

        if pais["poblacion"] > mayor["poblacion"]:
            mayor = pais

        if pais["poblacion"] < menor["poblacion"]:
            menor = pais

        cont = pais["continente"]

        if cont in continentes:
            continentes[cont] += 1
        else:
            continentes[cont] = 1

    print("\nESTADÍSTICAS")
    print("Mayor población:", mayor["nombre"])
    print("Menor población:", menor["nombre"])
    print("Promedio población:", suma_poblacion / len(paises))
    print("Promedio superficie:", suma_superficie / len(paises))

    print("\nPaíses por continente:")

    for continente in continentes:
        print(continente, ":", continentes[continente])


def main():     # Menú principal del programa

    paises = cargar_paises(RUTA_CSV)   # Carga los datos de los países desde el archivo CSV

    opcion = "0"

    while opcion != "11":       # Mientras la opción no sea 11, se mostrará el menú y se ejecutarán las funciones correspondientes

        print("\n===== GESTIÓN DE PAÍSES =====")
        print("1. Agregar país")
        print("2. Actualizar país")
        print("3. Buscar país")
        print("4. Filtrar por continente")
        print("5. Filtrar por población")
        print("6. Filtrar por superficie")
        print("7. Ordenar por nombre")
        print("8. Ordenar por población")
        print("9. Ordenar por superficie")
        print("10. Mostrar estadísticas")
        print("11. Guardar y salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            agregar_pais(paises)

        elif opcion == "2":
            actualizar_pais(paises)

        elif opcion == "3":
            buscar_pais(paises)

        elif opcion == "4":
            filtrar_continente(paises)

        elif opcion == "5":
            filtrar_poblacion(paises)

        elif opcion == "6":
            filtrar_superficie(paises)

        elif opcion == "7":
            ordenar_nombre(paises)

        elif opcion == "8":
            ordenar_poblacion(paises)

        elif opcion == "9":
            ordenar_superficie(paises)

        elif opcion == "10":
            mostrar_estadisticas(paises)

        elif opcion == "11":
            guardar_paises(RUTA_CSV, paises)
            print("Datos guardados correctamente.")

        else:
            print("Opción inválida.")     # Si la opción ingresada no es válida, se mostrará un mensaje de error


main()
